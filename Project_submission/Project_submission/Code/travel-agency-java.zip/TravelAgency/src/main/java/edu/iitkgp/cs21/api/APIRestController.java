package edu.iitkgp.cs21.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.iitkgp.cs21.common.Constants;

@CrossOrigin
@RestController
public class APIRestController {
	
	@Autowired
	private DataSource postgresDS;
	
	private final String SQL_QUERY_USER_BY_ID_PWD = "select userId, role from UserMaster where status = 'A' and userID = ? and password = ?";
	private final String SQL_QUERY_USER_AUTH = "select userIdRole, entityName, authList from UserRoleAuthorization where userIdRole = ?";
	
	private final String SQL_QUERY_VEHICLES = "select regId, make, model, sizeType, fuelType, isAC, chargePerHour, chargePerKm, status from VehicleMaster";
	
	//produces=MediaType enables consumers to know type of data returned
	@PostMapping(value="/api/validateLogin", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> validateLogin(@RequestBody String req) {
		JSONObject reqJson = new JSONObject(req);
		String userId = reqJson.optString(Constants.JSON_PROP_LOGIN_USER, "");
		String password = reqJson.optString(Constants.JSON_PROP_LOGIN_PASSWORD, "");
		
		try ( Connection conn = postgresDS.getConnection();
				PreparedStatement stmt = conn.prepareStatement(SQL_QUERY_USER_BY_ID_PWD);
				PreparedStatement authStmt = conn.prepareStatement(SQL_QUERY_USER_AUTH); ) {
			
			// Set SQL query execution parameters		
			stmt.setString(1, userId);
			stmt.setString(2, password);
			
			// Run SQL query and retrieve results
			stmt.execute();
			ResultSet rs = stmt.getResultSet();
			
			// If no results were returned by the query, return null
			if (rs == null || rs.next() == false) {
				return new ResponseEntity<String>(String.format(Constants.STATUS_ERROR, "\"Invalid User Id or Password\""), HttpStatus.UNAUTHORIZED);
			}
			
			// Marshall table row to JSON format
			JSONObject userJson = new JSONObject();
			userJson.put(Constants.JSON_PROP_USER_ID, rs.getString(Constants.COL_USER_ID));
			userJson.put(Constants.JSON_PROP_ROLE, rs.getString(Constants.COL_ROLE));
			
			// Now retrieve user's or role's authorization list
			authStmt.setString(1, userJson.getString(Constants.JSON_PROP_ROLE));
			authStmt.execute();
			ResultSet authRS = authStmt.getResultSet();
			
			JSONObject authListJson = new JSONObject();
			while (authRS != null && authRS.next()) {
				authListJson.put(authRS.getString(Constants.COL_ENTITY_NAME), new JSONObject(authRS.getString(Constants.COL_AUTH_LIST)));
				
			}
			
			if (authListJson.isEmpty() == false) {
				userJson.put(Constants.JSON_PROP_AUTH_LIST, authListJson);
			}
			
			// Finally return response containing role and authorization list by entity
			return new ResponseEntity<String>(userJson.toString(), HttpStatus.OK);
		}
		catch (Exception x) {
			x.printStackTrace();
			return new ResponseEntity<String>(String.format(Constants.STATUS_ERROR, x.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}				
		
	}
	
	@GetMapping (value = "/api/vehicle", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getVehicles() {
		try ( Connection conn = postgresDS.getConnection();
				PreparedStatement stmt = conn.prepareStatement(SQL_QUERY_VEHICLES)) {
			
			// Run SQL query and retrieve results
			stmt.execute();
			ResultSet rs = stmt.getResultSet();

			// Marshall table row to JSON format
			JSONArray vehiclesJsonArr = new JSONArray();
			while (rs != null && rs.next()) {
				JSONObject vehicleJson = new JSONObject();
				vehicleJson.put(Constants.JSON_PROP_REGISTRATION_ID, rs.getString(Constants.COL_REG_ID));
				vehicleJson.put(Constants.JSON_PROP_MAKE, rs.getString(Constants.COL_MAKE));
				vehicleJson.put(Constants.JSON_PROP_MODEL, rs.getString(Constants.COL_MODEL));
				vehicleJson.put(Constants.JSON_PROP_SIZE_TYPE, rs.getString(Constants.COL_SIZE_TYPE));
				vehicleJson.put(Constants.JSON_PROP_FUEL_TYPE, rs.getString(Constants.COL_FUEL_TYPE));
				vehicleJson.put(Constants.JSON_PROP_IS_AC, rs.getBoolean(Constants.COL_IS_AC));
				vehicleJson.put(Constants.JSON_PROP_CHARGE_HR, rs.getBigDecimal(Constants.COL_CHARGE_HR));
				vehicleJson.put(Constants.JSON_PROP_CHARGE_KM, rs.getBigDecimal(Constants.COL_CHARGE_KM));
				vehicleJson.put(Constants.JSON_PROP_STATUS, rs.getString(Constants.COL_STATUS));
				vehiclesJsonArr.put(vehicleJson);
			}
			
			// Finally return response containing role and authorization list by entity
			return new ResponseEntity<String>(vehiclesJsonArr.toString(), HttpStatus.OK);
		}
		catch (Exception x) {
			x.printStackTrace();
			return new ResponseEntity<String>(String.format(Constants.STATUS_ERROR, x.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
