package edu.iitkgp.cs21.common;

public class Constants {
	
	public static final String CHARSET_UTF8 = "UTF-8";
	
	public static final String COL_AUTH_LIST = "authList";
	public static final String COL_CHARGE_HR = "chargePerHour";
	public static final String COL_CHARGE_KM = "chargePerKm";
	public static final String COL_ENTITY_NAME = "entityName";
	public static final String COL_FUEL_TYPE = "fuelType";
	public static final String COL_IS_AC = "isAC";
	public static final String COL_MAKE = "make";
	public static final String COL_MODEL = "model";
	public static final String COL_REG_ID = "regId";
	public static final String COL_ROLE = "role";
	public static final String COL_SIZE_TYPE = "sizeType";
	public static final String COL_STATUS = "status";
	public static final String COL_USER_ID = "userID";
	
	public static final String JSON_PROP_AUTH = "authorization";
	public static final String JSON_PROP_AUTH_LIST = "authList";
	public static final String JSON_PROP_CHARGE_HR = "chargePerHour";
	public static final String JSON_PROP_CHARGE_KM = "chargePerKm";
	public static final String JSON_PROP_ENTITY = "entity";
	public static final String JSON_PROP_FUEL_TYPE = "fuelType";
	public static final String JSON_PROP_LOGIN_USER = "loginUser";
	public static final String JSON_PROP_LOGIN_PASSWORD = "loginPassword";
	public static final String JSON_PROP_IS_AC = "isAC";
	public static final String JSON_PROP_MAKE = "make";
	public static final String JSON_PROP_MODEL = "model";
	public static final String JSON_PROP_REGISTRATION_ID = "registrationId";
	public static final String JSON_PROP_ROLE = "role";
	public static final String JSON_PROP_SIZE_TYPE = "sizeType";
	public static final String JSON_PROP_STATUS = "status";
	public static final String JSON_PROP_USER_ID = "userId";
	
	public static final String STATUS_ERROR = "{ \"status\": \"error\", \"errors\": [ %s ] }";
	
}
