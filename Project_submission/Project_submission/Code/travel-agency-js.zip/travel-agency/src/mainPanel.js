import React, { Component } from 'react';
import './index.css';
import MenuDetails from './menuDetails';
import MainMenu from './mainMenu';

class MainPanel extends Component {

    //data passed as properties from index.js
    render() {
        return (
            <div id="mainPanel" className="mainPanel">
                <MainMenu data={this.props.data}/> 
                <div className="divider" id="divider"/>
                <div id="menuDetailsPanel" className="menuDetailsPanel">
                    <MenuDetails data={this.props.data}/>
                </div>
            </div>
        );
    }
    
}

//Reference to import in index.js
export default MainPanel;