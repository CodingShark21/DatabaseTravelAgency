import { Component } from "react";
import {createRoot} from "react-dom/client"
import MenuDetails from "./menuDetails";

var configSettings = require('./config/configSettings.js');
var config = configSettings.config;


class MainMenu extends Component {

    state = {
        menuData: [],
    }

    constructor(props) {
        super(props);
        this.menuItemClicked = this.menuItemClicked.bind(this);
    }

    componentDidMount() {
        console.log("Prop data: " + JSON.stringify(this.props.data)); 

        var entityIds = [];
        for (var entity in this.props.data.authList) {
            entityIds.push(entity);
        }

        console.log("Entity List: " + entityIds);

        var menuArr = [];
        for (var entityId in entityIds) {
            var entityDesc = config[entityIds[entityId]];
            var menuItem = {
                entityId: entityIds[entityId],
                entityDesc: entityDesc 
            }

            menuArr.push(menuItem);
        }

        console.log("Menu Array: " + JSON.stringify(menuArr));
        this.setState ({
            menuData: menuArr
        });

    }

    generateMenuTree() {
        var menuItems = this.state.menuData.map((menuItem) =>{
            return (
                <button className="collapsible" id={menuItem.entityId} onClick={this.menuItemClicked}>{menuItem.entityDesc}</button>
            );
        });

        return (
            <div className="menuOptionsPanel" id="menuOptions">{menuItems}</div>
        );
    }

    menuItemClicked(evt) {
        console.log("Event target id: " + evt.target.id);
        const container = document.getElementById('menuDetailsPanel');
        const root = createRoot(container);
        root.render(<MenuDetails data={this.props.data} detailsType={evt.target.id}/>);
    }

    render() {
        var menuTree = (this.state.menuData.length > 0 ) ? this.generateMenuTree() : null;
        return (
            <div id="menuTree" className="menuTree">
                {menuTree}
            </div>
        );
    }
}

export default MainMenu;