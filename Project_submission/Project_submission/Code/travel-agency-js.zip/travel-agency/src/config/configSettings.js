var config = {
    "baseURL": "http://localhost:8080",
    "booking": "Bookings Management",
    "expense": "Vehicle Expenses",
    "report": "Reports",
    "vehicle": "Vehicles Management",

}

module.exports = {
    config
}