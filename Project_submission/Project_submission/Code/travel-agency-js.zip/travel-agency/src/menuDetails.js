import { Component } from "react";
import viewDetailsButton from './images/icons8-search-24.png'

var configSettings = require('./config/configSettings.js');
var config = configSettings.config;

class menuDetails extends Component {

	state = {
		vehicles: []
	}

	componentDidMount() {
		if (this.props.detailsType === "vehicle") {
			this.loadVehicles();
		}
	}

	inspectDetails(evt) {
		var buttonId = evt.target.id;
		var button = document.getElementById(buttonId);

		if (! button.style.background || button.style.background === "none") {
				button.style.background = "darkgrey";
				button.style.border = "1px solid";
		}
		else {
			button.style.background = "none";
			button.style.border = "none";
		}
		
		var detailsDiv = null;
		if (buttonId === "showTransactions") {
			detailsDiv = document.getElementById("xactions");
		}
		else if (buttonId === "showDisbursements") {
			detailsDiv = document.getElementById("disbursements");
		}

		if (detailsDiv != null) {
			detailsDiv.style.display = (detailsDiv.style.display === 'block') ? 'none' : 'block';
		}
	} 

	loadVehicles() {
		fetch(`${config.baseURL}/api/vehicle`, 
			{
				method: 'GET',
				mode: 'cors'
			}
		)
		.then((response) => {
			if (response.status !== 200) {
				console.error('MenuDetails.loadVehicles(): API call not successful!');
			}
			else {
				response.json().then((data) => {
					this.setState(
						{
							vehicles: data
						}
					);
				});
			}
		});
	}

	renderDefault() {
		return (
			<h3 className="centeredMessage">Select from the list in left panel to view details here.</h3>
		);
	}

	formatNumberWithSeparators(num) {
		var numParts = num.split('.');
		var formattedNum = (numParts.length > 1) ? `.${numParts[1]}` : '';
		var numOfDigits = 3;
		var remainingLength = numParts[0].length;

		while (remainingLength > numOfDigits) {
			formattedNum = `,${numParts[0].slice((remainingLength - numOfDigits), remainingLength)}${formattedNum}`;
			remainingLength -= numOfDigits;
			numOfDigits = 2;
		}

		return `${numParts[0].slice(0, remainingLength)}${formattedNum}`;
	}

	renderVehicles() {
		var vehicleRows = (this.state.vehicles) 
								?	this.state.vehicles.map((vehicle) => {
										return (
											<tr>
												<td className="td_nonnumeric">{vehicle.registrationId}</td>
												<td className="td_nonnumeric">{vehicle.make}</td>
												<td className="td_nonnumeric">{vehicle.model}</td>
												<td className="td_nonnumeric">{vehicle.sizeType}</td>
												<td className="td_nonnumeric">{vehicle.fuelType}</td>
												<td className="td_nonnumeric">{(vehicle.isAC) ? "YES" : "NO"}</td>
												<td className="td_numeric">{vehicle.chargePerHour.toFixed(2)}</td>
												<td className="td_numeric">{vehicle.chargePerKm.toFixed(2)}</td>
												<td className="td_nonnumeric">{vehicle.status}</td>
											</tr>
										);
									}) 
								: 	null;
		return (
			<div id="vehiclesList">
				<h1>List of Vehicles</h1>
				<table id="disbTable">
					<thead>
						<tr>
							<th>Registration#</th>
							<th>Make</th>
							<th>Model</th>
							<th>Size Type</th>
							<th>Fuel Type</th>
							<th>Is AC?</th>
							<th className="th_numeric">Charge<br></br>per Hour</th>
							<th className="th_numeric">Charge per<br></br>Kilometer</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						{vehicleRows}
					</tbody>
				</table>
			</div>
		);
	}

	renderMenuDetails() {
		if (this.props.detailsType === "vehicle") {
			return this.renderVehicles();
		}
	}

	render() {
		const menuDetails = (this.props.detailsType) ? this.renderMenuDetails() : this.renderDefault();
        return (
			<div id="menuDetails" className="holdingDetails">
				{menuDetails}
			</div>
		);
    }
}

export default menuDetails;