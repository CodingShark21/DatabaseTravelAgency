import React, { Component } from 'react';
import {createRoot} from "react-dom/client"
import './index.css';
import checkButton from './images/icons8-check-mark-24.png'
import MainPanel from './mainPanel';

var configSettings = require('./config/configSettings.js');
var config = configSettings.config;

class App extends Component {

    state = {
        enteredPwd : ''
    }

    constructor(props) {
        super(props);
        //To pass this pointer to member functions
        this.handlePasswordInput = this.handlePasswordInput.bind(this);
        this.validateLogin = this.validateLogin.bind(this);
    }

    handlePasswordInput(evt) {
        var pwdVal = evt.target.value;
        var validateLoginButtonElem = document.getElementById("validateLoginPButton");
        validateLoginButtonElem.style.display = (pwdVal.length > 0) ? 'block' : 'none';
        
        //setState is to reflect the change in the green tick button
        this.setState( {
            enteredPwd: pwdVal
        });
    }

    validateLogin(evt) {
        var loginIdElem = document.getElementById("loginId");
        var loginPwdElem = document.getElementById("loginPwd");
        var loginJson = {
            loginUser: loginIdElem.value,
            loginPassword: loginPwdElem.value
        }

        fetch(`${config.baseURL}/api/validateLogin`, {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(loginJson)
        })
        .then((response) => {
            if (response.status !== 200) {
                response.json().then((data) => {
                    var errorColumn = document.getElementById("errorColumn");
                    errorColumn.innerHTML = data.errors[0];    
                });
            }
            else {
                response.json().then((data) => {
                    const container = document.getElementById('root');
                    const root = createRoot(container);
                    root.render(<MainPanel data={data}/>);
                });
            }
        });

    }

    //render called automatically after constructor
    render() {
        return (
            <div id="loginPanel" className="loginPanel">
                <h3>Login to Acme Travel Agency</h3>
                <table>
                    <tbody>
                        <tr id="rowLogin">
                            <td><label htmlFor="loginId">User ID:</label></td>
                            <td><input id="loginId" type="text" minLength={1} maxLength={50}/></td>
                            <td></td>
                        </tr>
                        <tr id="rowOTP">
                            <td><label id="loginPwdLabel" htmlFor="loginPwd">Password:</label></td>
                            <td><input id="loginPwd" type="password" minLength={1} maxLength={50} onInput={this.handlePasswordInput}/></td>
                            <td><img className="loginPwd" id="validateLoginPButton" alt="validateLogin" src={checkButton} onClick={this.validateLogin} title='Validate Login'/></td>
                        </tr>
                        <tr id="rowError">
                            <td className="error" colSpan={3} id="errorColumn"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );

    }
}

const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App/>);